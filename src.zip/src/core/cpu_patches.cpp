// SPDX-FileCopyrightText: Copyright 2024 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include <algorithm>
#include <atomic>
#include <iomanip>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <Zydis/Zydis.h>
#include <xbyak/xbyak.h>
#include <xbyak/xbyak_util.h>
#include "common/alignment.h"
#include "common/arch.h"
#include "common/assert.h"
#include "common/decoder.h"
#include "common/logging/log.h"
#include "common/signal_context.h"
#include "common/types.h"
#include "core/signals.h"
#include "core/tls.h"
#include "cpu_patches.h"

#ifdef _WIN32
#include <windows.h>
#else
#include <pthread.h>
#endif

using namespace Xbyak::util;

namespace Core {

static Xbyak::Reg ZydisToXbyakRegister(const ZydisRegister reg) {
    if (reg >= ZYDIS_REGISTER_EAX && reg <= ZYDIS_REGISTER_R15D) {
        return Xbyak::Reg32(reg - ZYDIS_REGISTER_EAX + Xbyak::Operand::EAX);
    }
    if (reg >= ZYDIS_REGISTER_RAX && reg <= ZYDIS_REGISTER_R15) {
        return Xbyak::Reg64(reg - ZYDIS_REGISTER_RAX + Xbyak::Operand::RAX);
    }
    if (reg >= ZYDIS_REGISTER_XMM0 && reg <= ZYDIS_REGISTER_XMM31) {
        return Xbyak::Xmm(reg - ZYDIS_REGISTER_XMM0 + xmm0.getIdx());
    }
    if (reg >= ZYDIS_REGISTER_YMM0 && reg <= ZYDIS_REGISTER_YMM31) {
        return Xbyak::Ymm(reg - ZYDIS_REGISTER_YMM0 + ymm0.getIdx());
    }
    UNREACHABLE_MSG("Unsupported register: {}", static_cast<u32>(reg));
}

static Xbyak::Reg ZydisToXbyakRegisterOperand(const ZydisDecodedOperand& operand) {
    ASSERT_MSG(operand.type == ZYDIS_OPERAND_TYPE_REGISTER,
               "Expected register operand, got type: {}", static_cast<u32>(operand.type));

    return ZydisToXbyakRegister(operand.reg.value);
}

static Xbyak::Address ZydisToXbyakMemoryOperand(const ZydisDecodedOperand& operand) {
    ASSERT_MSG(operand.type == ZYDIS_OPERAND_TYPE_MEMORY, "Expected memory operand, got type: {}",
               static_cast<u32>(operand.type));

    if (operand.mem.base == ZYDIS_REGISTER_RIP) {
        return ptr[rip + operand.mem.disp.value];
    }

    Xbyak::RegExp expression{};
    if (operand.mem.base != ZYDIS_REGISTER_NONE) {
        expression = expression + ZydisToXbyakRegister(operand.mem.base);
    }
    if (operand.mem.index != ZYDIS_REGISTER_NONE) {
        if (operand.mem.scale != 0) {
            expression = expression + ZydisToXbyakRegister(operand.mem.index) * operand.mem.scale;
        } else {
            expression = expression + ZydisToXbyakRegister(operand.mem.index);
        }
    }
    if (operand.mem.disp.size != 0 && operand.mem.disp.value != 0) {
        expression = expression + operand.mem.disp.value;
    }

    return ptr[expression];
}

static bool FilterTcbAccess(const ZydisDecodedOperand* operands) {
    const auto& dst_op = operands[0];
    const auto& src_op = operands[1];

    // Patch only 'mov (64-bit register), fs:[0]'
    return src_op.type == ZYDIS_OPERAND_TYPE_MEMORY && src_op.mem.segment == ZYDIS_REGISTER_FS &&
           src_op.mem.base == ZYDIS_REGISTER_NONE && src_op.mem.index == ZYDIS_REGISTER_NONE &&
           src_op.mem.disp.value == 0 && dst_op.reg.value >= ZYDIS_REGISTER_RAX &&
           dst_op.reg.value <= ZYDIS_REGISTER_R15;
}

static void GenerateTcbAccess(void* /* address */, const ZydisDecodedOperand* operands,
                              Xbyak::CodeGenerator& c) {
    const auto dst = ZydisToXbyakRegisterOperand(operands[0]);

#if defined(_WIN32)
    // The following logic is based on the Kernel32.dll asm of TlsGetValue
    static constexpr u32 TlsSlotsOffset = 0x1480;
    static constexpr u32 TlsExpansionSlotsOffset = 0x1780;
    static constexpr u32 TlsMinimumAvailable = 64;

    const auto slot = GetTcbKey();

    // Load the pointer to the table of TLS slots.
    c.putSeg(gs);
    if (slot < TlsMinimumAvailable) {
        // Load the pointer to TLS slots.
        c.mov(dst, ptr[reinterpret_cast<void*>(TlsSlotsOffset + slot * sizeof(LPVOID))]);
    } else {
        const u32 tls_index = slot - TlsMinimumAvailable;

        // Load the pointer to the table of TLS expansion slots.
        c.mov(dst, ptr[reinterpret_cast<void*>(TlsExpansionSlotsOffset)]);
        // Load the pointer to our buffer.
        c.mov(dst, qword[dst + tls_index * sizeof(LPVOID)]);
    }
#else
    const auto src = ZydisToXbyakMemoryOperand(operands[1]);

    // Replace fs read with gs read.
    c.putSeg(gs);
    c.mov(dst, src);
#endif
}

static bool FilterStackCheck(const ZydisDecodedOperand* operands) {
    const auto& dst_op = operands[0];
    const auto& src_op = operands[1];

    // Some compilers emit stack checks by starting a function with
    // 'mov (64-bit register), fs:[0x28]', then checking with `xor (64-bit register), fs:[0x28]`
    return src_op.type == ZYDIS_OPERAND_TYPE_MEMORY && src_op.mem.segment == ZYDIS_REGISTER_FS &&
           src_op.mem.base == ZYDIS_REGISTER_NONE && src_op.mem.index == ZYDIS_REGISTER_NONE &&
           src_op.mem.disp.value == 0x28 && dst_op.reg.value >= ZYDIS_REGISTER_RAX &&
           dst_op.reg.value <= ZYDIS_REGISTER_R15;
}

static void GenerateStackCheck(void* /* address */, const ZydisDecodedOperand* operands,
                               Xbyak::CodeGenerator& c) {
    const auto dst = ZydisToXbyakRegisterOperand(operands[0]);
    c.xor_(dst, 0);
}

static void GenerateStackCanary(void* /* address */, const ZydisDecodedOperand* operands,
                                Xbyak::CodeGenerator& c) {
    const auto dst = ZydisToXbyakRegisterOperand(operands[0]);
    c.mov(dst, 0);
}

static bool FilterNoSSE4a(const ZydisDecodedOperand*) {
    Cpu cpu;
    return !cpu.has(Cpu::tSSE4a);
}

static void GenerateEXTRQ(void* /* address */, const ZydisDecodedOperand* operands,
                          Xbyak::CodeGenerator& c) {
    bool immediateForm = operands[1].type == ZYDIS_OPERAND_TYPE_IMMEDIATE &&
                         operands[2].type == ZYDIS_OPERAND_TYPE_IMMEDIATE;

    ASSERT_MSG(operands[0].type == ZYDIS_OPERAND_TYPE_REGISTER, "operand 0 must be a register");

    const auto dst = ZydisToXbyakRegisterOperand(operands[0]);

    ASSERT_MSG(dst.isXMM(), "operand 0 must be an XMM register");

    Xbyak::Xmm xmm_dst = *reinterpret_cast<const Xbyak::Xmm*>(&dst);

    if (immediateForm) {
        u8 length = operands[1].imm.value.u & 0x3F;
        u8 index = operands[2].imm.value.u & 0x3F;

        LOG_DEBUG(Core, "Patching immediate form EXTRQ, length: {}, index: {}", length, index);

        const Xbyak::Reg64 scratch1 = rax;
        const Xbyak::Reg64 scratch2 = rcx;

        // Set rsp to before red zone and save scratch registers
        c.lea(rsp, ptr[rsp - 128]);
        c.pushfq();
        c.push(scratch1);
        c.push(scratch2);

        u64 mask;
        if (length == 0) {
            length = 64; // for the check below
            mask = 0xFFFF'FFFF'FFFF'FFFF;
        } else {
            mask = (1ULL << length) - 1;
        }

        if (length + index > 64) {
            mask = 0xFFFF'FFFF'FFFF'FFFF;
        }

        // Get lower qword from xmm register
        c.vmovq(scratch1, xmm_dst);

        if (index != 0) {
            c.shr(scratch1, index);
        }

        // We need to move mask to a register because we can't use all the possible
        // immediate values with `and reg, imm32`
        c.mov(scratch2, mask);
        c.and_(scratch1, scratch2);

        // Writeback to xmm register, extrq instruction says top 64-bits are undefined but zeroed on
        // AMD CPUs
        c.vmovq(xmm_dst, scratch1);

        c.pop(scratch2);
        c.pop(scratch1);
        c.popfq();
        c.lea(rsp, ptr[rsp + 128]);
    } else {
        ASSERT_MSG(operands[0].type == ZYDIS_OPERAND_TYPE_REGISTER &&
                       operands[1].type == ZYDIS_OPERAND_TYPE_REGISTER &&
                       operands[0].reg.value >= ZYDIS_REGISTER_XMM0 &&
                       operands[0].reg.value <= ZYDIS_REGISTER_XMM15 &&
                       operands[1].reg.value >= ZYDIS_REGISTER_XMM0 &&
                       operands[1].reg.value <= ZYDIS_REGISTER_XMM15,
                   "Unexpected operand types for EXTRQ instruction");

        const auto src = ZydisToXbyakRegisterOperand(operands[1]);

        ASSERT_MSG(src.isXMM(), "operand 1 must be an XMM register");

        Xbyak::Xmm xmm_src = *reinterpret_cast<const Xbyak::Xmm*>(&src);

        const Xbyak::Reg64 scratch1 = rax;
        const Xbyak::Reg64 scratch2 = rcx;
        const Xbyak::Reg64 mask = rdx;

        Xbyak::Label length_zero, end;

        c.lea(rsp, ptr[rsp - 128]);
        c.pushfq();
        c.push(scratch1);
        c.push(scratch2);
        c.push(mask);

        // Construct the mask out of the length that resides in bottom 6 bits of source xmm
        c.vmovq(scratch1, xmm_src);
        c.mov(scratch2, scratch1);
        c.and_(scratch2, 0x3F);
        c.jz(length_zero);

        // mask = (1ULL << length) - 1
        c.mov(mask, 1);
        c.shl(mask, cl);
        c.dec(mask);
        c.jmp(end);

        c.L(length_zero);
        c.mov(mask, 0xFFFF'FFFF'FFFF'FFFF);

        c.L(end);

        // Get the shift amount and store it in scratch2
        c.shr(scratch1, 8);
        c.and_(scratch1, 0x3F);
        c.mov(scratch2, scratch1); // cl now contains the shift amount

        c.vmovq(scratch1, xmm_dst);
        c.shr(scratch1, cl);
        c.and_(scratch1, mask);
        c.vmovq(xmm_dst, scratch1);

        c.pop(mask);
        c.pop(scratch2);
        c.pop(scratch1);
        c.popfq();
        c.lea(rsp, ptr[rsp + 128]);
    }
}

static void GenerateINSERTQ(void* /* address */, const ZydisDecodedOperand* operands,
                            Xbyak::CodeGenerator& c) {
    bool immediateForm = operands[2].type == ZYDIS_OPERAND_TYPE_IMMEDIATE &&
                         operands[3].type == ZYDIS_OPERAND_TYPE_IMMEDIATE;

    ASSERT_MSG(operands[0].type == ZYDIS_OPERAND_TYPE_REGISTER &&
                   operands[1].type == ZYDIS_OPERAND_TYPE_REGISTER,
               "operands 0 and 1 must be registers.");

    const auto dst = ZydisToXbyakRegisterOperand(operands[0]);
    const auto src = ZydisToXbyakRegisterOperand(operands[1]);

    ASSERT_MSG(dst.isXMM() && src.isXMM(), "operands 0 and 1 must be xmm registers.");

    Xbyak::Xmm xmm_dst = *reinterpret_cast<const Xbyak::Xmm*>(&dst);
    Xbyak::Xmm xmm_src = *reinterpret_cast<const Xbyak::Xmm*>(&src);

    if (immediateForm) {
        u8 length = operands[2].imm.value.u & 0x3F;
        u8 index = operands[3].imm.value.u & 0x3F;

        const Xbyak::Reg64 scratch1 = rax;
        const Xbyak::Reg64 scratch2 = rcx;
        const Xbyak::Reg64 mask = rdx;

        // Set rsp to before red zone and save scratch registers
        c.lea(rsp, ptr[rsp - 128]);
        c.pushfq();
        c.push(scratch1);
        c.push(scratch2);
        c.push(mask);

        u64 mask_value;
        if (length == 0) {
            length = 64; // for the check below
            mask_value = 0xFFFF'FFFF'FFFF'FFFF;
        } else {
            mask_value = (1ULL << length) - 1;
        }

        if (length + index > 64) {
            mask_value = 0xFFFF'FFFF'FFFF'FFFF;
        }

        c.vmovq(scratch1, xmm_src);
        c.vmovq(scratch2, xmm_dst);
        c.mov(mask, mask_value);

        // src &= mask
        c.and_(scratch1, mask);

        // src <<= index
        c.shl(scratch1, index);

        // dst &= ~(mask << index)
        mask_value = ~(mask_value << index);
        c.mov(mask, mask_value);
        c.and_(scratch2, mask);

        // dst |= src
        c.or_(scratch2, scratch1);

        // Insert scratch2 into low 64 bits of dst, upper 64 bits are undefined but zeroed on AMD
        // CPUs
        c.vmovq(xmm_dst, scratch2);

        c.pop(mask);
        c.pop(scratch2);
        c.pop(scratch1);
        c.popfq();
        c.lea(rsp, ptr[rsp + 128]);
    } else {
        ASSERT_MSG(operands[2].type == ZYDIS_OPERAND_TYPE_UNUSED &&
                       operands[3].type == ZYDIS_OPERAND_TYPE_UNUSED,
                   "operands 2 and 3 must be unused for register form.");

        const Xbyak::Reg64 scratch1 = rax;
        const Xbyak::Reg64 scratch2 = rcx;
        const Xbyak::Reg64 index = rdx;
        const Xbyak::Reg64 mask = rbx;

        Xbyak::Label length_zero, end;

        c.lea(rsp, ptr[rsp - 128]);
        c.pushfq();
        c.push(scratch1);
        c.push(scratch2);
        c.push(index);
        c.push(mask);

        // Get upper 64 bits of src and copy it to mask and index
        c.vpextrq(index, xmm_src, 1);
        c.mov(mask, index);

        // When length is 0, set it to 64
        c.and_(mask, 0x3F); // mask now holds the length
        c.jz(length_zero);  // Check if length is 0 and set mask to all 1s if it is

        // Create a mask out of the length
        c.mov(cl, mask.cvt8());
        c.mov(mask, 1);
        c.shl(mask, cl);
        c.dec(mask);
        c.jmp(end);

        c.L(length_zero);
        c.mov(mask, 0xFFFF'FFFF'FFFF'FFFF);

        c.L(end);
        // Get index to insert at
        c.shr(index, 8);
        c.and_(index, 0x3F);

        // src &= mask
        c.vmovq(scratch1, xmm_src);
        c.and_(scratch1, mask);

        // mask = ~(mask << index)
        c.mov(cl, index.cvt8());
        c.shl(mask, cl);
        c.not_(mask);

        // src <<= index
        c.shl(scratch1, cl);

        // dst = (dst & mask) | src
        c.vmovq(scratch2, xmm_dst);
        c.and_(scratch2, mask);
        c.or_(scratch2, scratch1);

        // Upper 64 bits are undefined in insertq but AMD CPUs zero them
        c.vmovq(xmm_dst, scratch2);

        c.pop(mask);
        c.pop(index);
        c.pop(scratch2);
        c.pop(scratch1);
        c.popfq();
        c.lea(rsp, ptr[rsp + 128]);
    }
}

static void ReplaceMOVNT(void* address, u8 rep_prefix) {
    // Find the opcode byte
    // There can be any amount of prefixes but the instruction can't be more than 15 bytes
    // And we know for sure this is a MOVNTSS/MOVNTSD
    bool found = false;
    bool rep_prefix_found = false;
    int index = 0;
    u8* ptr = reinterpret_cast<u8*>(address);
    for (int i = 0; i < 15; i++) {
        if (ptr[i] == rep_prefix) {
            rep_prefix_found = true;
        } else if (ptr[i] == 0x2B) {
            index = i;
            found = true;
            break;
        }
    }

    // Some sanity checks
    ASSERT(found);
    ASSERT(index >= 2);
    ASSERT(ptr[index - 1] == 0x0F);
    ASSERT(rep_prefix_found);

    // This turns the MOVNTSS/MOVNTSD to a MOVSS/MOVSD m, xmm
    ptr[index] = 0x11;
}

static void ReplaceMOVNTSS(void* address, const ZydisDecodedOperand*, Xbyak::CodeGenerator&) {
    ReplaceMOVNT(address, 0xF3);
}

static void ReplaceMOVNTSD(void* address, const ZydisDecodedOperand*, Xbyak::CodeGenerator&) {
    ReplaceMOVNT(address, 0xF2);
}

using PatchFilter = bool (*)(const ZydisDecodedOperand*);
using InstructionGenerator = void (*)(void*, const ZydisDecodedOperand*, Xbyak::CodeGenerator&);
struct PatchInfo {
    /// Filter for more granular patch conditions past just the instruction mnemonic.
    PatchFilter filter;

    /// Generator for the patch/trampoline.
    InstructionGenerator generator;

    /// Whether to use a trampoline for this patch.
    bool trampoline;
};

static const std::unordered_map<ZydisMnemonic, std::vector<PatchInfo>> Patches = {
    // SSE4a
    {ZYDIS_MNEMONIC_EXTRQ, {{FilterNoSSE4a, GenerateEXTRQ, true}}},
    {ZYDIS_MNEMONIC_INSERTQ, {{FilterNoSSE4a, GenerateINSERTQ, true}}},
    {ZYDIS_MNEMONIC_MOVNTSS, {{FilterNoSSE4a, ReplaceMOVNTSS, false}}},
    {ZYDIS_MNEMONIC_MOVNTSD, {{FilterNoSSE4a, ReplaceMOVNTSD, false}}},

#if !defined(__APPLE__)
    // FS segment patches
    // These first two patches are for accesses to the stack canary, fs:[0x28]
    {ZYDIS_MNEMONIC_XOR, {{FilterStackCheck, GenerateStackCheck, false}}},
    {ZYDIS_MNEMONIC_MOV,
     {{FilterStackCheck, GenerateStackCanary, false},
#if defined(_WIN32)
      // Windows needs a trampoline for Tcb accesses.
      {FilterTcbAccess, GenerateTcbAccess, true}
#else
      {FilterTcbAccess, GenerateTcbAccess, false}
#endif
     }},
#endif
};

static std::once_flag init_flag;

struct PatchModule {
    /// Mutex controlling access to module code regions.
    std::mutex mutex{};

    /// Start of the module.
    u8* start;

    /// End of the module.
    u8* end;

    /// Tracker for patched code locations.
    std::set<u8*> patched;

    /// Code generator for patching the module.
    Xbyak::CodeGenerator patch_gen;

    /// Code generator for writing trampoline patches.
    Xbyak::CodeGenerator trampoline_gen;

    PatchModule(u8* module_ptr, const u64 module_size, u8* trampoline_ptr,
                const u64 trampoline_size)
        : start(module_ptr), end(module_ptr + module_size), patch_gen(module_size, module_ptr),
          trampoline_gen(trampoline_size, trampoline_ptr) {}
};
static std::map<u64, PatchModule> modules;

static PatchModule* GetModule(const void* ptr) {
    auto upper_bound = modules.upper_bound(reinterpret_cast<u64>(ptr));
    if (upper_bound == modules.begin()) {
        return nullptr;
    }
    return &(std::prev(upper_bound)->second);
}

/// Returns a boolean indicating whether the instruction was patched, and the offset to advance past
/// whatever is at the current code pointer.
static std::pair<bool, u64> TryPatch(u8* code, PatchModule* module) {
    ZydisDecodedInstruction instruction;
    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
    const auto status = Common::Decoder::Instance()->decodeInstruction(instruction, operands, code,
                                                                       module->end - code);
    if (!ZYAN_SUCCESS(status)) {
        return std::make_pair(false, 1);
    }

    if (Patches.contains(instruction.mnemonic)) {
        const auto& patches = Patches.at(instruction.mnemonic);
        for (const auto& patch_info : patches) {
            bool needs_trampoline = patch_info.trampoline;
            if (patch_info.filter(operands)) {
                auto& patch_gen = module->patch_gen;

                if (needs_trampoline && instruction.length < 5) {
                    // Trampoline is needed but instruction is too short to patch.
                    // Return false and length to signal to AOT compilation that this instruction
                    // should be skipped and handled at runtime.
                    return std::make_pair(false, instruction.length);
                }

                // Reset state and move to current code position.
                patch_gen.reset();
                patch_gen.setSize(code - patch_gen.getCode());

                if (needs_trampoline) {
                    auto& trampoline_gen = module->trampoline_gen;
                    const auto trampoline_ptr = trampoline_gen.getCurr();

                    patch_info.generator(code, operands, trampoline_gen);

                    // Return to the following instruction at the end of the trampoline.
                    trampoline_gen.jmp(code + instruction.length);

                    // Replace instruction with near jump to the trampoline.
                    patch_gen.jmp(trampoline_ptr, Xbyak::CodeGenerator::LabelType::T_NEAR);
                } else {
                    patch_info.generator(code, operands, patch_gen);
                }

                const auto patch_size = patch_gen.getCurr() - code;
                if (patch_size > 0) {
                    ASSERT_MSG(instruction.length >= patch_size,
                               "Instruction {} with length {} is too short to replace at: {}",
                               ZydisMnemonicGetString(instruction.mnemonic), instruction.length,
                               fmt::ptr(code));

                    // Fill remaining space with nops.
                    patch_gen.nop(instruction.length - patch_size);

                    module->patched.insert(code);
                    LOG_DEBUG(Core, "Patched instruction '{}' at: {}",
                              ZydisMnemonicGetString(instruction.mnemonic), fmt::ptr(code));
                    return std::make_pair(true, instruction.length);
                }
            }
        }
    }

    return std::make_pair(false, instruction.length);
}

#if defined(ARCH_X86_64)

static bool Is4ByteExtrqOrInsertq(void* code_address) {
    u8* bytes = (u8*)code_address;
    if (bytes[0] == 0x66 && bytes[1] == 0x0F && bytes[2] == 0x79) {
        return true; // extrq
    } else if (bytes[0] == 0xF2 && bytes[1] == 0x0F && bytes[2] == 0x79) {
        return true; // insertq
    } else {
        return false;
    }
}

static bool TryExecuteIllegalInstruction(void* ctx, void* code_address) {
    // We need to decode the instruction to find out what it is. Normally we'd use a fully fleshed
    // out decoder like Zydis, however Zydis does a bunch of stuff that impact performance that we
    // don't care about. We can get information about the instruction a lot faster by writing a mini
    // decoder here, since we know it is definitely an extrq or an insertq. If for some reason we
    // need to interpret more instructions in the future (I don't see why we would), we can revert
    // to using Zydis.
    ZydisMnemonic mnemonic;
    u8* bytes = (u8*)code_address;
    if (bytes[0] == 0x66) {
        mnemonic = ZYDIS_MNEMONIC_EXTRQ;
    } else if (bytes[0] == 0xF2) {
        mnemonic = ZYDIS_MNEMONIC_INSERTQ;
    } else {
        ZydisDecodedInstruction instruction;
        ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
        const auto status =
            Common::Decoder::Instance()->decodeInstruction(instruction, operands, code_address);
        LOG_ERROR(Core, "Unhandled illegal instruction at code address {}: {}",
                  fmt::ptr(code_address),
                  ZYAN_SUCCESS(status) ? ZydisMnemonicGetString(instruction.mnemonic)
                                       : "Failed to decode");
        return false;
    }

    ASSERT(bytes[1] == 0x0F && bytes[2] == 0x79);

    // Note: It's guaranteed that there's no REX prefix in these instructions checked by
    // Is4ByteExtrqOrInsertq
    u8 modrm = bytes[3];
    u8 rm = modrm & 0b111;
    u8 reg = (modrm >> 3) & 0b111;
    u8 mod = (modrm >> 6) & 0b11;

    ASSERT(mod == 0b11); // Any instruction we interpret here uses reg/reg addressing only

    int dstIndex = reg;
    int srcIndex = rm;

    switch (mnemonic) {
    case ZYDIS_MNEMONIC_EXTRQ: {
        const auto dst = Common::GetXmmPointer(ctx, dstIndex);
        const auto src = Common::GetXmmPointer(ctx, srcIndex);

        u64 lowQWordSrc;
        memcpy(&lowQWordSrc, src, sizeof(lowQWordSrc));

        u64 lowQWordDst;
        memcpy(&lowQWordDst, dst, sizeof(lowQWordDst));

        u64 length = lowQWordSrc & 0x3F;
        u64 mask;
        if (length == 0) {
            length = 64; // for the check below
            mask = 0xFFFF'FFFF'FFFF'FFFF;
        } else {
            mask = (1ULL << length) - 1;
        }

        u64 index = (lowQWordSrc >> 8) & 0x3F;
        if (length + index > 64) {
            // Undefined behavior if length + index is bigger than 64 according to the spec,
            // we'll warn and continue execution.
            LOG_TRACE(Core,
                      "extrq at {} with length {} and index {} is bigger than 64, "
                      "undefined behavior",
                      fmt::ptr(code_address), length, index);
        }

        lowQWordDst >>= index;
        lowQWordDst &= mask;

        memset((u8*)dst + sizeof(u64), 0, sizeof(u64));
        memcpy(dst, &lowQWordDst, sizeof(lowQWordDst));

        Common::IncrementRip(ctx, 4);

        return true;
    }
    case ZYDIS_MNEMONIC_INSERTQ: {
        const auto dst = Common::GetXmmPointer(ctx, dstIndex);
        const auto src = Common::GetXmmPointer(ctx, srcIndex);

        u64 lowQWordSrc, highQWordSrc;
        memcpy(&lowQWordSrc, src, sizeof(lowQWordSrc));
        memcpy(&highQWordSrc, (u8*)src + 8, sizeof(highQWordSrc));

        u64 lowQWordDst;
        memcpy(&lowQWordDst, dst, sizeof(lowQWordDst));

        u64 length = highQWordSrc & 0x3F;
        u64 mask;
        if (length == 0) {
            length = 64; // for the check below
            mask = 0xFFFF'FFFF'FFFF'FFFF;
        } else {
            mask = (1ULL << length) - 1;
        }

        u64 index = (highQWordSrc >> 8) & 0x3F;
        if (length + index > 64) {
            // Undefined behavior if length + index is bigger than 64 according to the spec,
            // we'll warn and continue execution.
            LOG_TRACE(Core,
                      "insertq at {} with length {} and index {} is bigger than 64, "
                      "undefined behavior",
                      fmt::ptr(code_address), length, index);
        }

        lowQWordSrc &= mask;
        lowQWordDst &= ~(mask << index);
        lowQWordDst |= lowQWordSrc << index;

        memset((u8*)dst + sizeof(u64), 0, sizeof(u64));
        memcpy(dst, &lowQWordDst, sizeof(lowQWordDst));

        Common::IncrementRip(ctx, 4);

        return true;
    }
    default: {
        UNREACHABLE();
    }
    }

    UNREACHABLE();
}
#elif defined(ARCH_ARM64)
// These functions shouldn't be needed for ARM as it will use a JIT so there's no need to patch
// instructions.
static bool TryExecuteIllegalInstruction(void*, void*) {
    return false;
}
#else
#error "Unsupported architecture"
#endif

static bool TryPatchJit(void* code_address) {
    auto* code = static_cast<u8*>(code_address);
    auto* module = GetModule(code);
    if (module == nullptr) {
        return false;
    }

    std::unique_lock lock{module->mutex};

    // Return early if already patched, in case multiple threads signaled at the same time.
    if (std::ranges::find(module->patched, code) != module->patched.end()) {
        return true;
    }

    return TryPatch(code, module).first;
}

static void TryPatchAot(void* code_address, u64 code_size) {
    auto* code = static_cast<u8*>(code_address);
    auto* module = GetModule(code);
    if (module == nullptr) {
        return;
    }

    std::unique_lock lock{module->mutex};

    const auto* end = code + code_size;
    while (code < end) {
        code += TryPatch(code, module).second;
    }
}

#if defined(_WIN32)

/// Returns true for SSE4a mnemonics that are safe to AOT-patch regardless of
/// TLS / FS-segment state. EXTRQ/INSERTQ/MOVNTSS/MOVNTSD generators emit pure
/// XMM+GPR code and have no segment-register dependencies.
static bool IsSSE4aMnemonic(ZydisMnemonic mnemonic) {
    return mnemonic == ZYDIS_MNEMONIC_EXTRQ || mnemonic == ZYDIS_MNEMONIC_INSERTQ ||
           mnemonic == ZYDIS_MNEMONIC_MOVNTSS || mnemonic == ZYDIS_MNEMONIC_MOVNTSD;
}

// =====================================================================
// AOT relocator for 4-byte EXTRQ_rr / INSERTQ_rr.
//
// The default Windows-only AOT path patches >=5-byte SSE4a sites with a
// JMP-to-trampoline. The 4-byte reg/reg forms are shorter than a near-jmp
// (5 bytes) so they cannot be patched in place — they're left to trap at
// runtime via the illegal-instruction VEH handler.
//
// On Intel Windows, that runtime trap path is a frame-time killer
// (~1.3M traps/sec observed in GR2; ~10k+ cycles per trap on intel-win due
// to kernel-side exception dispatch and "mutex-style" waits in the kernel
// during delivery). The fix here is to relocate the 4-byte rr-form to a
// trampoline by also consuming the NEXT instruction's bytes:
//
//   original bytes:  [4-byte EXTRQ_rr][next instr, len L]
//   patched window:  [5-byte JMP rel32 → trampoline][NOPx(4+L-5)]
//   trampoline:      [emulate EXTRQ_rr][replay next instr][JMP back]
//
// Constraints on the next instruction (verified pre-patch):
//   - Must be decodable.
//   - Must not be a branch (we can't reorder a branch into the trampoline
//     without rewriting its target).
//   - Must not use RIP-relative addressing (relocation would shift the
//     effective address). We could fix up rip-rel disps but for GR2 v1.11
//     none of the 40 trap sites have a rip-rel next instruction, so we
//     simply refuse to relocate when one would be needed.
//
// If the next instruction is itself an SSE4a op (the adjacent EXTRQ_rr
// cases) we emit emulation for it instead of copying bytes verbatim,
// otherwise the copy would just trap again from inside the trampoline.
//
// Diagnostics: counters track how many 4-byte rr sites are seen, how many
// are relocated, and how many are skipped (with reasons). A per-module
// summary line is logged at the end of the AOT pass. The runtime trap
// counters (g_ud_trap_4byte_sse4a_count, g_ud_trap_other_count, g_av_count
// below) are the cross-check: if relocation is working, the SSE4a-rr
// counter stays at 0 in steady state.
// =====================================================================

struct AotSse4aStats {
    std::atomic<u64> rr_sites_seen{0};
    std::atomic<u64> rr_sites_relocated{0};
    std::atomic<u64> rr_skipped_next_decode_fail{0};
    std::atomic<u64> rr_skipped_next_is_branch{0};
    std::atomic<u64> rr_skipped_next_rip_rel{0};
    std::atomic<u64> rr_skipped_at_module_end{0};
    std::atomic<u64> rr_skipped_other{0};

    u64 total_skipped() const {
        return rr_skipped_next_decode_fail.load(std::memory_order_relaxed) +
               rr_skipped_next_is_branch.load(std::memory_order_relaxed) +
               rr_skipped_next_rip_rel.load(std::memory_order_relaxed) +
               rr_skipped_at_module_end.load(std::memory_order_relaxed) +
               rr_skipped_other.load(std::memory_order_relaxed);
    }
};
static AotSse4aStats g_aot_sse4a_stats;

static bool IsBranchOrCall(const ZydisDecodedInstruction& inst) {
    switch (inst.meta.category) {
    case ZYDIS_CATEGORY_UNCOND_BR:
    case ZYDIS_CATEGORY_COND_BR:
    case ZYDIS_CATEGORY_CALL:
    case ZYDIS_CATEGORY_RET:
    case ZYDIS_CATEGORY_SYSCALL:
    case ZYDIS_CATEGORY_SYSRET:
    case ZYDIS_CATEGORY_INTERRUPT:
        return true;
    default:
        return false;
    }
}

static bool UsesRipRelative(const ZydisDecodedInstruction& inst,
                            const ZydisDecodedOperand* operands) {
    for (u8 i = 0; i < inst.operand_count_visible; ++i) {
        const auto& op = operands[i];
        if (op.type == ZYDIS_OPERAND_TYPE_MEMORY &&
            op.mem.base == ZYDIS_REGISTER_RIP) {
            return true;
        }
    }
    return false;
}

/// Returns true and the new advance length if the 4-byte EXTRQ_rr / INSERTQ_rr
/// at `code` was successfully relocated to a trampoline. Returns false (and
/// `inst.length` = 4 for the caller to advance) if the site was skipped.
static std::pair<bool, u64> TryRelocate4ByteSse4aRr(
    u8* code, PatchModule* module, const ZydisDecodedInstruction& inst,
    const ZydisDecodedOperand* operands) {

    g_aot_sse4a_stats.rr_sites_seen.fetch_add(1, std::memory_order_relaxed);

    // Decode the next instruction.
    if (code + inst.length >= module->end) {
        g_aot_sse4a_stats.rr_skipped_at_module_end.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }
    ZydisDecodedInstruction next_inst;
    ZydisDecodedOperand next_operands[ZYDIS_MAX_OPERAND_COUNT];
    const auto next_status = Common::Decoder::Instance()->decodeInstruction(
        next_inst, next_operands, code + inst.length, module->end - (code + inst.length));
    if (!ZYAN_SUCCESS(next_status)) {
        g_aot_sse4a_stats.rr_skipped_next_decode_fail.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }

    if (IsBranchOrCall(next_inst)) {
        g_aot_sse4a_stats.rr_skipped_next_is_branch.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }
    if (UsesRipRelative(next_inst, next_operands)) {
        g_aot_sse4a_stats.rr_skipped_next_rip_rel.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }

    // Combined window = 4 + L. With L >= 1 this is always >= 5 for the JMP rel32.
    const u64 total_window = inst.length + next_inst.length;
    if (total_window < 5) {
        // Shouldn't happen — even a 1-byte next yields a 5-byte window — but guard.
        g_aot_sse4a_stats.rr_skipped_other.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }

    auto& trampoline_gen = module->trampoline_gen;
    auto& patch_gen = module->patch_gen;
    const auto* tramp_ptr = trampoline_gen.getCurr();

    // Trampoline body 1: emulate the 4-byte EXTRQ_rr / INSERTQ_rr.
    if (inst.mnemonic == ZYDIS_MNEMONIC_EXTRQ) {
        GenerateEXTRQ(code, operands, trampoline_gen);
    } else {
        ASSERT(inst.mnemonic == ZYDIS_MNEMONIC_INSERTQ);
        GenerateINSERTQ(code, operands, trampoline_gen);
    }

    // Trampoline body 2: handle the next instruction.
    //   - If it's itself SSE4a, emit emulation (don't copy verbatim or it would
    //     just trap from inside the trampoline).
    //   - Otherwise, copy bytes verbatim — safety has been verified
    //     (no branch, no rip-rel).
    if (next_inst.mnemonic == ZYDIS_MNEMONIC_EXTRQ) {
        GenerateEXTRQ(code + inst.length, next_operands, trampoline_gen);
    } else if (next_inst.mnemonic == ZYDIS_MNEMONIC_INSERTQ) {
        GenerateINSERTQ(code + inst.length, next_operands, trampoline_gen);
    } else if (next_inst.mnemonic == ZYDIS_MNEMONIC_MOVNTSS ||
               next_inst.mnemonic == ZYDIS_MNEMONIC_MOVNTSD) {
        // These have non-trampoline generators that emit in-place replacement
        // bytes equal in length to the original. We can call them and they'll
        // emit into the trampoline stream — same effect as inline replacement,
        // since the trampoline isn't being checked for size here.
        if (next_inst.mnemonic == ZYDIS_MNEMONIC_MOVNTSS) {
            ReplaceMOVNTSS(code + inst.length, next_operands, trampoline_gen);
        } else {
            ReplaceMOVNTSD(code + inst.length, next_operands, trampoline_gen);
        }
    } else {
        // Verbatim copy of the next instruction's bytes.
        for (u64 i = 0; i < next_inst.length; ++i) {
            trampoline_gen.db(code[inst.length + i]);
        }
    }

    // Trampoline tail: jump back to (original_VA + 4 + next.length).
    trampoline_gen.jmp(code + total_window);

    // Now overwrite the source site: 5-byte JMP to trampoline + NOPs.
    patch_gen.reset();
    patch_gen.setSize(code - patch_gen.getCode());
    patch_gen.jmp(tramp_ptr, Xbyak::CodeGenerator::LabelType::T_NEAR);
    const auto patch_size = patch_gen.getCurr() - code;
    if (patch_size < 0 || static_cast<u64>(patch_size) > total_window) {
        // Should not happen — JMP rel32 is always 5 bytes — but stay defensive.
        g_aot_sse4a_stats.rr_skipped_other.fetch_add(1, std::memory_order_relaxed);
        return std::make_pair(false, inst.length);
    }
    patch_gen.nop(total_window - static_cast<u64>(patch_size));
    module->patched.insert(code);

    g_aot_sse4a_stats.rr_sites_relocated.fetch_add(1, std::memory_order_relaxed);
    LOG_DEBUG(Core,
              "AOT relocated 4-byte SSE4a-rr at {} ({}+{}b next={} → window={}b)",
              fmt::ptr(code), ZydisMnemonicGetString(inst.mnemonic),
              static_cast<int>(next_inst.length),
              ZydisMnemonicGetString(next_inst.mnemonic),
              static_cast<int>(total_window));

    return std::make_pair(true, total_window);
}

/// Like TryPatch, but only patches SSE4a mnemonics. Other patchable
/// instructions (FS-segment stack canary, Tcb access) are left to lazy
/// patching via the illegal-instruction VEH handler, since they depend on
/// the PS4 TLS layout being established after module load.
///
/// If the existing dispatcher can't handle the site (e.g., 4-byte EXTRQ_rr
/// or INSERTQ_rr), TryRelocate4ByteSse4aRr is invoked to claim 4 + next_len
/// bytes and emit a combined trampoline.
static std::pair<bool, u64> TryPatchSSE4aOnly(u8* code, PatchModule* module) {
    ZydisDecodedInstruction instruction;
    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
    const auto status = Common::Decoder::Instance()->decodeInstruction(instruction, operands, code,
                                                                       module->end - code);
    if (!ZYAN_SUCCESS(status)) {
        return std::make_pair(false, 1);
    }
    if (!IsSSE4aMnemonic(instruction.mnemonic)) {
        return std::make_pair(false, instruction.length);
    }

    // First, try the existing dispatcher. This handles >= 5-byte forms cleanly
    // (EXTRQ_imm, INSERTQ_imm, MOVNTSS, MOVNTSD with REX, etc.).
    auto result = TryPatch(code, module);
    if (result.first) {
        return result;
    }

    // The existing path declined. If this is a 4-byte rr-form of EXTRQ or
    // INSERTQ, try the relocator.
    const bool is_4byte_rr = (instruction.length == 4) &&
                             (instruction.mnemonic == ZYDIS_MNEMONIC_EXTRQ ||
                              instruction.mnemonic == ZYDIS_MNEMONIC_INSERTQ);
    if (is_4byte_rr) {
        return TryRelocate4ByteSse4aRr(code, module, instruction, operands);
    }

    return std::make_pair(false, instruction.length);
}

/// AOT walk that only patches SSE4a mnemonics. Used on Windows where the
/// generic AOT path is otherwise disabled. This eliminates VEH dispatch cost
/// for first-time execution of patchable SSE4a sites (6-byte EXTRQ-imm,
/// INSERTQ-imm, MOVNTSS, MOVNTSD). The 4-byte register-register EXTRQ/INSERTQ
/// forms used to remain unpatchable and were left to the illegal-instruction
/// handler; the relocator above now claims them too by consuming the next
/// instruction's bytes.
static void TryPatchAotSSE4aOnly(void* code_address, u64 code_size) {
    auto* code = static_cast<u8*>(code_address);
    auto* module = GetModule(code);
    if (module == nullptr) {
        return;
    }

    std::unique_lock lock{module->mutex};

    // Snapshot counters so we can report deltas for this pass (the global
    // counters are cumulative across modules).
    const u64 before_seen = g_aot_sse4a_stats.rr_sites_seen.load(std::memory_order_relaxed);
    const u64 before_reloc = g_aot_sse4a_stats.rr_sites_relocated.load(std::memory_order_relaxed);
    const u64 before_skip = g_aot_sse4a_stats.total_skipped();

    const auto* end = code + code_size;
    while (code < end) {
        code += TryPatchSSE4aOnly(code, module).second;
    }

    const u64 seen   = g_aot_sse4a_stats.rr_sites_seen.load(std::memory_order_relaxed) - before_seen;
    const u64 reloc  = g_aot_sse4a_stats.rr_sites_relocated.load(std::memory_order_relaxed) - before_reloc;
    const u64 skip   = g_aot_sse4a_stats.total_skipped() - before_skip;
    if (seen > 0) {
        LOG_INFO(Core,
                 "AOT SSE4a-rr relocator: segment [{} +{:#x}b] — 4-byte rr sites: seen={}, "
                 "relocated={}, skipped={} (decode_fail={}, branch={}, rip_rel={}, "
                 "module_end={}, other={})",
                 fmt::ptr(code_address), code_size, seen, reloc, skip,
                 g_aot_sse4a_stats.rr_skipped_next_decode_fail.load(std::memory_order_relaxed),
                 g_aot_sse4a_stats.rr_skipped_next_is_branch.load(std::memory_order_relaxed),
                 g_aot_sse4a_stats.rr_skipped_next_rip_rel.load(std::memory_order_relaxed),
                 g_aot_sse4a_stats.rr_skipped_at_module_end.load(std::memory_order_relaxed),
                 g_aot_sse4a_stats.rr_skipped_other.load(std::memory_order_relaxed));
    }
}

#endif

// =====================================================================
// Runtime trap diagnostics.
//
// Three independent counters cover all kernel exception-dispatch paths
// that can blocking-stall threads on Intel Windows:
//
//   g_ud_trap_4byte_sse4a_count
//       Increments when a 4-byte EXTRQ_rr / INSERTQ_rr traps post-AOT.
//       The AOT relocator should drive this to 0. Any growth means a
//       site slipped through (check the AOT summary's `skipped=*`
//       breakdown).
//
//   g_ud_trap_other_count
//       Increments on any other illegal-instruction trap — typically
//       Windows-lazy FS-segment patches that present as UD (stack canary
//       `mov`, Tcb-access `mov`, etc.). These should taper as the working
//       set of patchable sites is exhausted; sustained growth implies a
//       persistent untraversed-code-path cost.
//
//   g_av_count / g_av_handled_count
//       Access-violation handler hits. On Windows the FS-segment patches
//       (`fs:[0x28]` stack canary, `fs:[0x0]` Tcb) trap as access
//       violations until lazily patched. `handled` = TryPatchJit
//       succeeded. Persistent unpatched AVs flow elsewhere (other
//       handlers / crash).
//
// All counters use the same coarse geometric log schedule so a fully-
// working state produces no output, and a hot bottleneck produces one
// log line per ~1 second at typical trap rates.
// =====================================================================

static std::atomic<u64> g_ud_trap_4byte_sse4a_count{0};
static std::atomic<u64> g_ud_trap_other_count{0};
static std::atomic<u64> g_av_count{0};
static std::atomic<u64> g_av_handled_count{0};

static inline bool ShouldLogTrapCounter(u64 n) {
    // 1st, 1K, 16K, 256K, then every 1M.
    return n == 1 || n == 1024 || n == 16384 || n == 262144 ||
           (n & ((1ull << 20) - 1)) == 0;
}

static bool PatchesAccessViolationHandler(void* context, void* /* fault_address */) {
    const u64 n = g_av_count.fetch_add(1, std::memory_order_relaxed) + 1;
    const bool handled = TryPatchJit(Common::GetRip(context));
    if (handled) {
        g_av_handled_count.fetch_add(1, std::memory_order_relaxed);
    }
    if (ShouldLogTrapCounter(n)) {
        LOG_WARNING(Core,
                    "Access-violation patch handler fired (cumulative_seen={}, "
                    "cumulative_handled={}). First-execution FS-segment patches "
                    "amortize to ~0 over time; sustained growth implies persistent "
                    "page-fault dispatch cost on Intel Windows.",
                    n, g_av_handled_count.load(std::memory_order_relaxed));
    }
    return handled;
}

static bool PatchesIllegalInstructionHandler(void* context) {
    void* code_address = Common::GetRip(context);
    if (Is4ByteExtrqOrInsertq(code_address)) {
        const u64 n =
            g_ud_trap_4byte_sse4a_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (ShouldLogTrapCounter(n)) {
            LOG_WARNING(Core,
                        "4-byte SSE4a-rr trap fired post-AOT (cumulative={}). "
                        "The AOT relocator should have covered this site — check "
                        "its summary line's `skipped=*` breakdown.",
                        n);
        }
        // The instruction is not big enough for a relative jump, don't try to patch it and pass it
        // to our illegal instruction interpreter directly
        return TryExecuteIllegalInstruction(context, code_address);
    } else {
        const u64 n =
            g_ud_trap_other_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (ShouldLogTrapCounter(n)) {
            LOG_WARNING(Core,
                        "Non-SSE4a illegal-instruction trap fired (cumulative={}). "
                        "Most likely a Windows-lazy FS-segment patch (stack canary / "
                        "Tcb access) presenting as UD. Should taper as new code paths "
                        "are exhausted.",
                        n);
        }
        if (!TryPatchJit(code_address)) {
            ZydisDecodedInstruction instruction;
            ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
            const auto status =
                Common::Decoder::Instance()->decodeInstruction(instruction, operands, code_address);
            if (ZYAN_SUCCESS(status) && instruction.mnemonic == ZydisMnemonic::ZYDIS_MNEMONIC_UD2)
                [[unlikely]] {
                UNREACHABLE_MSG("ud2 at code address {:#x}", reinterpret_cast<u64>(code_address));
            }
            UNREACHABLE_MSG("Failed to patch address {:x} -- mnemonic: {}",
                            reinterpret_cast<u64>(code_address),
                            ZYAN_SUCCESS(status) ? ZydisMnemonicGetString(instruction.mnemonic)
                                                 : "Failed to decode");
        }
    }

    return true;
}

static void PatchesInit() {
    if (!Patches.empty()) {
        auto* signals = Signals::Instance();
        // Should be called last.
        constexpr auto priority = std::numeric_limits<u32>::max();
        signals->RegisterAccessViolationHandler(PatchesAccessViolationHandler, priority);
        signals->RegisterIllegalInstructionHandler(PatchesIllegalInstructionHandler, priority);
    }
}

void RegisterPatchModule(void* module_ptr, u64 module_size, void* trampoline_area_ptr,
                         u64 trampoline_area_size) {
    std::call_once(init_flag, PatchesInit);

    const auto module_addr = reinterpret_cast<u64>(module_ptr);
    modules.emplace(std::piecewise_construct, std::forward_as_tuple(module_addr),
                    std::forward_as_tuple(static_cast<u8*>(module_ptr), module_size,
                                          static_cast<u8*>(trampoline_area_ptr),
                                          trampoline_area_size));
}

void PrePatchInstructions(u64 segment_addr, u64 segment_size) {
#if !defined(_WIN32) && !defined(__APPLE__)
    // Linux and others have an FS segment pointing to valid memory, so continue to do full
    // ahead-of-time patching for now until a better solution is worked out.
    if (!Patches.empty()) {
        TryPatchAot(reinterpret_cast<void*>(segment_addr), segment_size);
    }
#elif defined(_WIN32) && defined(ARCH_X86_64)
    // Windows: AOT-patch SSE4a mnemonics only. FS-segment patches (stack
    // canary, Tcb access) must remain lazy because they depend on the PS4
    // TLS layout being set up after module load.
    //
    // PS4 libc uses EXTRQ/INSERTQ aggressively in memcpy/memmove and other
    // hot SIMD paths. With this disabled, every first-execution of those
    // sites traps as an illegal-instruction exception, dispatched via
    // KiUserExceptionDispatcher -> our VEH handler -> TryPatchJit. On Intel
    // Windows this dispatch path has been observed to be a significant
    // frame-time cost in profiling (mutex-style kernel waits inside
    // exception delivery), and on AMD it's a smaller but still real cost.
    // AOT-patching at module load amortizes this to a one-time bulk pass.
    if (!Patches.empty()) {
        TryPatchAotSSE4aOnly(reinterpret_cast<void*>(segment_addr), segment_size);
    }
#endif
}

} // namespace Core
